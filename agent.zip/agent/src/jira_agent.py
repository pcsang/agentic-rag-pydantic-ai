"""
Jira Agent for Issue Management using FastMCP Client
Connects to Jira MCP server via HTTP for comprehensive Jira operations
"""

from pydantic_ai import Agent
from pydantic_ai.toolsets.fastmcp import FastMCPToolset
from pydantic_ai.ag_ui import StateDeps
from tools import ProverbsState
import os
from dotenv import load_dotenv
import logging

# Setup logger first
logger = logging.getLogger(__name__)

# Langfuse observability
try:
    from langfuse import observe, Langfuse
    LANGFUSE_AVAILABLE = True
    
    # Initialize Langfuse client with credentials from environment
    langfuse_client = Langfuse(
        secret_key=os.getenv("LANGFUSE_SECRET_KEY"),
        public_key=os.getenv("LANGFUSE_PUBLIC_KEY"),
        host=os.getenv("LANGFUSE_HOST", os.getenv("LANGFUSE_BASE_URL"))
    )
    logger.info("Langfuse client initialized for Jira")
    
except ImportError:
    # Create a no-op decorator if Langfuse is not available
    def observe(*args, **kwargs):
        def decorator(func):
            return func
        if len(args) == 1 and callable(args[0]):
            return args[0]
        return decorator
    LANGFUSE_AVAILABLE = False
except Exception as e:
    logger.warning(f"Langfuse initialization failed: {e}")
    def observe(*args, **kwargs):
        def decorator(func):
            return func
        if len(args) == 1 and callable(args[0]):
            return args[0]
        return decorator
    LANGFUSE_AVAILABLE = False

if LANGFUSE_AVAILABLE:
    logger.info("Langfuse tracing enabled for Jira agent")

# Load environment variables
load_dotenv()

print("🎫 JIRA AGENT INITIALIZING")
print("=" * 60)

MCP_URL = os.getenv("MCP_SERVER_URL", "http://localhost:9000/mcp")
JIRA_URL = os.getenv("JIRA_URL", "")
JIRA_USERNAME = os.getenv("JIRA_USERNAME", "")

print(f"📡 MCP Server: {MCP_URL}")
print(f"🔗 Jira Instance: {JIRA_URL}")
print(f"👤 Jira User: {JIRA_USERNAME}")

# Create FastMCP toolset from HTTP URL
# This automatically connects to the MCP server and loads all available tools
try:
    jira_toolset = FastMCPToolset(MCP_URL)
    print("✅ FastMCP toolset created successfully")
except Exception as e:
    print(f"⚠️ Warning: Failed to create FastMCP toolset: {e}")
    print("   Agent will be created but may not have access to Jira tools")
    jira_toolset = None

# Create Jira agent with FastMCP toolset
jira_agent = Agent(
    name="jira_agent",
    model="openai:gpt-4o-mini",
    system_prompt=f"""You are an expert Jira assistant helping users manage issues, projects, and workflows.

## Connected Jira Instance
- URL: {JIRA_URL}
- User: {JIRA_USERNAME}

## Your Capabilities
You have access to comprehensive Jira tools through MCP for:
- 🔍 Searching and filtering issues with JQL (Jira Query Language)
- 📋 Getting detailed issue information
- ✏️ Creating and updating issues
- 💬 Adding comments and work logs
- 🔗 Linking issues and managing relationships
- 📊 Working with projects, versions, and boards
- 🏃 Managing sprints and agile workflows
- 👤 User and permission management

## JQL Query Guidelines
**IMPORTANT**: Jira Cloud API requires bounded queries. NEVER use unbounded queries like "ORDER BY created DESC" alone.

✅ CORRECT Query Examples:
- `project = TEST ORDER BY created DESC` - Search in TEST project
- `project = TEST OR project = SEC ORDER BY created DESC` - Search in multiple projects  
- `project = TEST AND assignee = "Kiet Ho"` - Filter by project and assignee
- `assignee = currentUser() ORDER BY updated DESC` - Current user's issues
- `status = "In Progress" AND project = TEST` - Status filter with project

❌ INCORRECT (Will Fail):
- `ORDER BY created DESC` - Missing project constraint
- `assignee = "Kiet Ho"` alone - Should include project
- Any query without project, assignee=currentUser(), or other bounds

When user asks to "list all issues", ALWAYS:
1. First get all projects using jira_get_all_projects
2. Then search with: `project IN (PROJECT1, PROJECT2, ...) ORDER BY created DESC`
3. Or use: `assignee = currentUser() ORDER BY created DESC` for user's issues

- For searching by assignee: use `assignee = "User Name"` or `assignee = "email@domain.com"`
- For project filtering: `project = "PROJECT_KEY"` or `project IN (KEY1, KEY2)`
- For status: `status = "In Progress"` or `status IN ("Open", "In Progress")`
- Combine with AND/OR: `project = TEST AND assignee = "Kiet Ho" AND status = "Open"`
- Order results: `ORDER BY created DESC` or `ORDER BY updated DESC`
- Limit results: use the `limit` parameter in search functions

## Response Guidelines
- Always format results clearly with issue keys, summaries, and status
- When listing issues, show key details: KEY, summary, status, assignee, priority
- For empty results, explain politely and suggest alternatives
- If you encounter errors, explain them clearly to the user
- Provide actionable information and next steps when appropriate
""",
    toolsets=[jira_toolset] if jira_toolset else [],
    retries=2
)

# Wrap jira_agent.run with observe decorator for Langfuse tracing
if LANGFUSE_AVAILABLE:
    original_run = jira_agent.run
    jira_agent.run = observe(name="jira-agent-run", as_type="span")(original_run)
    logger.info("Jira agent instrumented with Langfuse")

print("✅ Jira Agent created with FastMCP toolset")
print("=" * 60)

__all__ = ["jira_agent", "ProverbsState"]
