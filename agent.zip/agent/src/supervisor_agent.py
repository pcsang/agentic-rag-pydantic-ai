"""
Supervisor Agent - Multi-Agent Orchestration with Pydantic Graph

Architecture:
- Supervisor Agent: Entry point, routes to specialized agents
- RAG Agent: Handles document queries (local, web, hybrid)  
- Jira Agent: Manages Jira tickets (get, list, comment, create)
"""

from __future__ import annotations
from dataclasses import dataclass, field
from typing import Literal
from pydantic import BaseModel
from pydantic_ai import Agent
from pydantic_graph import BaseNode, End, Graph, GraphRunContext
import logging
import sys
import os

# Setup logger first
logger = logging.getLogger(__name__)

# Langfuse observability
try:
    from langfuse import observe, Langfuse
    LANGFUSE_AVAILABLE = True
    
    # Initialize Langfuse client with credentials from environment
    langfuse_client = Langfuse(
        secret_key=os.getenv("LANGFUSE_SECRET_KEY"),
        public_key=os.getenv("LANGFUSE_PUBLIC_KEY"),
        host=os.getenv("LANGFUSE_HOST", os.getenv("LANGFUSE_BASE_URL"))
    )
    logger.info("Langfuse client initialized for Supervisor")
    
except ImportError:
    # Create a no-op decorator if Langfuse is not available
    def observe(*args, **kwargs):
        def decorator(func):
            return func
        if len(args) == 1 and callable(args[0]):
            return args[0]
        return decorator
    LANGFUSE_AVAILABLE = False
except Exception as e:
    logger.warning(f"Langfuse initialization failed: {e}")
    def observe(*args, **kwargs):
        def decorator(func):
            return func
        if len(args) == 1 and callable(args[0]):
            return args[0]
        return decorator
    LANGFUSE_AVAILABLE = False

if LANGFUSE_AVAILABLE:
    logger.info("Langfuse tracing enabled for Supervisor agent")

# Import existing agents
from rag_agent import handle_query as rag_handle_query
from jira_agent import jira_agent

logger = logging.getLogger(__name__)

# ============================================================================
# State Definition
# ============================================================================

@dataclass
class SupervisorState:
    """State shared across all nodes in the graph"""
    query: str
    rag_response: str | None = None
    jira_response: str | None = None
    final_response: str | None = None
    messages: list[str] = field(default_factory=list)


# ============================================================================
# Router Agent - Decides which specialized agent(s) to use
# ============================================================================

class RouteDecision(BaseModel):
    """Decision on which agent(s) to invoke"""
    use_rag: bool
    use_jira: bool
    reasoning: str


router_agent = Agent(
    model="openai:gpt-4.1-mini",
    output_type=RouteDecision,
    system_prompt="""You are a routing agent that analyzes user queries and decides which specialized agents to invoke.

Available Agents:
1. RAG Agent - Document retrieval and knowledge base queries
   - Use for: questions about technical documentation, configuration, how-to guides
   - Use for: "how to", "what is", "explain", "configure", "setup", "install"
   - Use for: CVE information, security docs, troubleshooting guides
   - Modes: local only, web only, or hybrid (local + web)
   
2. Jira Agent - Project management and ticket operations
   - Use ONLY for: listing existing tickets, querying issues, creating/updating tickets
   - Keywords: "list issues", "show tickets", "create ticket", "jira", "comment on"
   - Operations: get all issues, list by filter, add comments, create new issues

Routing Logic (IMPORTANT):
1. Technical/Configuration Questions → RAG ONLY
   Examples: "how to config X?", "what is Y?", "setup Z", "deployment profile"
   Decision: use_rag=True, use_jira=False

2. Jira Ticket Operations → JIRA ONLY  
   Examples: "list all issues", "show tickets for project X", "create a ticket"
   Decision: use_rag=False, use_jira=True

3. Combined Operations → BOTH AGENTS
   Examples: "list tickets about CVE-2023-48975 and explain the CVE"
   Examples: "create a ticket based on the TMA documentation"
   Decision: use_rag=True, use_jira=True

4. Ambiguous/General Questions → RAG ONLY (default)
   If unclear which agent, default to RAG for information retrieval
   Decision: use_rag=True, use_jira=False

Key Rules:
- Do NOT route configuration/documentation questions to Jira
- Only use Jira when explicitly managing tickets/issues
- When in doubt, choose RAG agent

Provide clear reasoning for your routing decision."""
)


# ============================================================================
# Graph Nodes
# ============================================================================

@dataclass
class RouterNode(BaseNode[SupervisorState]):
    """Entry point - analyzes query and routes to appropriate agent(s)"""
    
    @observe(name="supervisor-router", as_type="span")
    async def run(
        self, 
        ctx: GraphRunContext[SupervisorState]
    ) -> RAGNode | JiraNode | BothAgentsNode:
        """Route based on query analysis"""
        
        ctx.state.messages.append(f"🤔 Analyzing query: {ctx.state.query}")
        
        # Use router agent to decide
        result = await router_agent.run(
            f"Analyze this query and decide which agent(s) to use: {ctx.state.query}"
        )
        
        decision = result.output
        ctx.state.messages.append(f"📋 Routing decision: {decision.reasoning}")
        
        if decision.use_rag and decision.use_jira:
            return BothAgentsNode()
        elif decision.use_rag:
            return RAGNode()
        else:
            return JiraNode()


@dataclass
class RAGNode(BaseNode[SupervisorState]):
    """Executes RAG agent for document queries"""
    
    @observe(name="supervisor-rag-node", as_type="span")
    async def run(
        self, 
        ctx: GraphRunContext[SupervisorState]
    ) -> ResponseNode:
        """Run RAG agent"""
        
        ctx.state.messages.append("📚 Querying RAG agent...")
        
        try:
            # Call the agentic RAG system
            result = await rag_handle_query(ctx.state.query)
            ctx.state.rag_response = result.get('answer', '')
            ctx.state.messages.append(f"✅ RAG response received")
            
        except Exception as e:
            error_msg = f"Error in RAG agent: {str(e)}"
            ctx.state.rag_response = error_msg
            ctx.state.messages.append(f"❌ {error_msg}")
            logger.error(error_msg, exc_info=True)
        
        return ResponseNode()


@dataclass  
class JiraNode(BaseNode[SupervisorState]):
    """Executes Jira agent for ticket management"""
    
    @observe(name="supervisor-jira-node", as_type="span")
    async def run(
        self, 
        ctx: GraphRunContext[SupervisorState]
    ) -> ResponseNode:
        """Run Jira agent"""
        
        ctx.state.messages.append("🎫 Querying Jira agent...")
        
        try:
            # Call the Jira agent
            result = await jira_agent.run(ctx.state.query)
            
            # Extract clean text from result
            if hasattr(result, 'data'):
                ctx.state.jira_response = result.data
            elif hasattr(result, 'output'):
                ctx.state.jira_response = result.output
            else:
                ctx.state.jira_response = str(result)
            
            ctx.state.messages.append(f"✅ Jira response received")
            
        except Exception as e:
            error_msg = f"Error in Jira agent: {str(e)}"
            ctx.state.jira_response = error_msg
            ctx.state.messages.append(f"❌ {error_msg}")
            logger.error(error_msg, exc_info=True)
        
        return ResponseNode()


@dataclass
class BothAgentsNode(BaseNode[SupervisorState]):
    """Executes both RAG and Jira agents in parallel for faster response"""
    
    @observe(name="supervisor-both-agents-node", as_type="span")
    async def run(
        self, 
        ctx: GraphRunContext[SupervisorState]
    ) -> ResponseNode:
        """Run both agents in parallel"""
        
        ctx.state.messages.append("🔄 Running both RAG and Jira agents in parallel...")
        
        async def run_rag():
            """Run RAG agent"""
            try:
                result = await rag_handle_query(ctx.state.query)
                ctx.state.rag_response = result.get('answer', '')
                ctx.state.messages.append("✅ RAG response received")
            except Exception as e:
                error_msg = f"Error in RAG agent: {str(e)}"
                ctx.state.rag_response = error_msg
                ctx.state.messages.append(f"❌ {error_msg}")
                logger.error(error_msg, exc_info=True)
        
        async def run_jira():
            """Run Jira agent"""
            try:
                result = await jira_agent.run(ctx.state.query)
                
                # Extract clean text from result
                if hasattr(result, 'data'):
                    ctx.state.jira_response = result.data
                elif hasattr(result, 'output'):
                    ctx.state.jira_response = result.output
                else:
                    ctx.state.jira_response = str(result)
                
                ctx.state.messages.append("✅ Jira response received")
            except Exception as e:
                error_msg = f"Error in Jira agent: {str(e)}"
                ctx.state.jira_response = error_msg
                ctx.state.messages.append(f"❌ {error_msg}")
                logger.error(error_msg, exc_info=True)
        
        # Run both agents in parallel using asyncio.gather
        import asyncio
        await asyncio.gather(run_rag(), run_jira())
        
        return ResponseNode()


@dataclass
class ResponseNode(BaseNode[SupervisorState, None, str]):
    """Final node - synthesizes responses and returns result quickly"""
    
    @observe(name="supervisor-response-node", as_type="span")
    async def run(
        self, 
        ctx: GraphRunContext[SupervisorState]
    ) -> End[str]:
        """Synthesize final response efficiently"""
        
        ctx.state.messages.append("🎯 Synthesizing final response...")
        
        # Build final response with clear structure
        parts = []
        
        # Add RAG response if available
        if ctx.state.rag_response:
            # Trim excessive whitespace for faster rendering
            rag_clean = ctx.state.rag_response.strip()
            parts.append(f"**📚 Knowledge Base:**\n{rag_clean}")
        
        # Add Jira response if available
        if ctx.state.jira_response:
            jira_clean = ctx.state.jira_response.strip()
            parts.append(f"**🎫 Jira Tickets:**\n{jira_clean}")
        
        # Generate final response
        if not parts:
            final_response = "⚠️ No results found. Please try rephrasing your question."
        elif len(parts) == 1:
            # Single source - return directly for speed
            final_response = parts[0]
        else:
            # Multiple sources - combine with clear separator
            final_response = "\n\n---\n\n".join(parts)
        
        ctx.state.final_response = final_response
        ctx.state.messages.append("✅ Response ready")
        
        return End(final_response)


# ============================================================================
# Graph Definition
# ============================================================================

supervisor_graph = Graph(
    nodes=[RouterNode, RAGNode, JiraNode, BothAgentsNode, ResponseNode],
    state_type=SupervisorState
)


# ============================================================================
# Main Entry Point
# ============================================================================

@observe(name="supervisor-query", as_type="span")
async def supervisor_query(query: str, timeout: int = 120) -> dict:
    """
    Main entry point for the supervisor agent with timeout protection.
    
    Args:
        query: User query to process
        timeout: Maximum time in seconds (default: 120s)
        
    Returns:
        Dictionary with response and metadata
    """
    import asyncio
    import time
    
    logger.info(f"Supervisor received query: {query}")
    start_time = time.time()
    
    try:
        # Initialize state
        state = SupervisorState(query=query)
        
        # Run the graph with timeout
        result = await asyncio.wait_for(
            supervisor_graph.run(RouterNode(), state=state),
            timeout=timeout
        )
        
        elapsed_time = time.time() - start_time
        logger.info(f"Query completed in {elapsed_time:.2f}s")
        
        # Return structured response
        result = {
            "query": query,
            "response": result.output,
            "rag_response": state.rag_response,
            "jira_response": state.jira_response,
            "execution_log": state.messages,
            "execution_time": f"{elapsed_time:.2f}s",
            "success": True
        }
        
        # Flush Langfuse data to ensure it's sent
        if LANGFUSE_AVAILABLE:
            try:
                langfuse_client.flush()
            except Exception as e:
                logger.warning(f"Failed to flush Langfuse data: {e}")
        
        return result
        
    except asyncio.TimeoutError:
        elapsed_time = time.time() - start_time
        logger.error(f"Query timeout after {elapsed_time:.2f}s")
        return {
            "query": query,
            "response": f"⏱️ Query timeout after {timeout}s. Please try a simpler query or try again later.",
            "rag_response": None,
            "jira_response": None,
            "execution_log": [f"❌ Timeout after {timeout}s"],
            "execution_time": f"{elapsed_time:.2f}s",
            "success": False
        }
    except Exception as e:
        elapsed_time = time.time() - start_time
        logger.error(f"Error in supervisor: {str(e)}", exc_info=True)
        return {
            "query": query,
            "response": f"❌ Error processing query: {str(e)}",
            "rag_response": None,
            "jira_response": None,
            "execution_log": [f"❌ Error: {str(e)}"],
            "execution_time": f"{elapsed_time:.2f}s",
            "success": False
        }


# ============================================================================
# Visualization Helper
# ============================================================================

def generate_graph_diagram(filename: str = "supervisor_graph.png"):
    """Generate mermaid diagram of the supervisor graph"""
    try:
        supervisor_graph.mermaid_save(
            filename,
            start_node=RouterNode,
            direction='TB'
        )
        print(f"Graph diagram saved to {filename}")
    except Exception as e:
        print(f"Could not generate diagram: {e}")
        # Print mermaid code instead
        code = supervisor_graph.mermaid_code(
            start_node=RouterNode,
            direction='TB'
        )
        print("\nMermaid diagram code:")
        print(code)


# For testing
if __name__ == "__main__":
    import asyncio
    
    # Test queries
    test_queries = [
        "tell me information about TMA solution",
        "list all jira issues",
        "create a ticket for implementing the TMA solution based on the documentation"
    ]
    
    async def test():
        for query in test_queries:
            print(f"\n{'='*60}")
            print(f"Query: {query}")
            print('='*60)
            
            result = await supervisor_query(query)
            
            print("\nExecution Log:")
            for msg in result['execution_log']:
                print(f"  {msg}")
            
            print(f"\nFinal Response:\n{result['response']}")
    
    asyncio.run(test())
    
    # Generate diagram
    print("\n" + "="*60)
    print("Generating graph diagram...")
    generate_graph_diagram()
