#!/usr/bin/env python3
"""
Comprehensive Test Suite for Multi-Agent System
Tests RAG Agent, Jira Agent, and Supervisor Agent workflows
"""
import asyncio
import httpx
import json
from typing import Dict, Any
from datetime import datetime

# Base URL for the backend server
BASE_URL = "http://localhost:8000"

# Test results tracking
test_results = []


class TestCase:
    """Test case structure"""
    def __init__(self, name: str, endpoint: str, payload: Dict[str, Any], expected_fields: list):
        self.name = name
        self.endpoint = endpoint
        self.payload = payload
        self.expected_fields = expected_fields
        self.result = None
        self.passed = False
        self.error = None
        self.duration = 0


def print_header(title: str):
    """Print formatted section header"""
    print("\n" + "=" * 80)
    print(f"  {title}")
    print("=" * 80)


def print_test_result(test: TestCase):
    """Print formatted test result"""
    status = "✅ PASS" if test.passed else "❌ FAIL"
    print(f"\n{status} | {test.name}")
    print(f"Duration: {test.duration:.2f}s")
    
    if test.error:
        print(f"Error: {test.error}")
    elif test.result:
        # Print key response fields
        if isinstance(test.result, dict):
            if 'answer' in test.result:
                print(f"Answer: {test.result['answer'][:150]}...")
            elif 'response' in test.result:
                print(f"Response: {str(test.result['response'])[:150]}...")
            if 'sources' in test.result:
                print(f"Sources: {len(test.result['sources'])}")


async def run_test(test: TestCase) -> TestCase:
    """Execute a single test case"""
    print(f"\n▶ Running: {test.name}")
    start_time = datetime.now()
    
    try:
        async with httpx.AsyncClient(timeout=120.0) as client:
            response = await client.post(
                f"{BASE_URL}{test.endpoint}",
                json=test.payload
            )
            
            test.duration = (datetime.now() - start_time).total_seconds()
            
            if response.status_code == 200:
                test.result = response.json()
                
                # Check expected fields
                missing_fields = [
                    field for field in test.expected_fields 
                    if field not in test.result
                ]
                
                if not missing_fields:
                    test.passed = True
                else:
                    test.error = f"Missing expected fields: {missing_fields}"
            else:
                test.error = f"HTTP {response.status_code}: {response.text[:200]}"
                
    except Exception as e:
        test.duration = (datetime.now() - start_time).total_seconds()
        test.error = str(e)
    
    return test


async def test_rag_agent():
    """Test RAG Agent with various query types"""
    print_header("RAG AGENT TESTS")
    
    tests = [
        TestCase(
            name="RAG-1: Local Document Query (TMA Solution)",
            endpoint="/rag",
            payload={"question": "tell me information about TMA solution"},
            expected_fields=["answer", "sources", "strategy"]
        ),
        TestCase(
            name="RAG-2: Web Search Query (Current Events)",
            endpoint="/rag",
            payload={"question": "What is the latest version of Docker in 2025?"},
            expected_fields=["answer", "sources", "strategy"]
        ),
        TestCase(
            name="RAG-3: Hybrid Query (Partial Local Info)",
            endpoint="/rag",
            payload={"question": "Compare TMA solution with modern network management tools"},
            expected_fields=["answer", "sources", "strategy"]
        ),
        TestCase(
            name="RAG-4: Technical Documentation Query",
            endpoint="/rag",
            payload={"question": "Documents related to the keyword 'Alarm'"},
            expected_fields=["answer", "sources", "strategy"]
        ),
        TestCase(
            name="RAG-5: General Knowledge Query",
            endpoint="/rag",
            payload={"question": "What is Python programming language?"},
            expected_fields=["answer", "sources", "strategy"]
        )
    ]
    
    for test in tests:
        result = await run_test(test)
        test_results.append(result)
        print_test_result(result)


async def test_jira_agent():
    """Test Jira Agent with various operations"""
    print_header("JIRA AGENT TESTS")
    
    tests = [
        TestCase(
            name="JIRA-1: List All Issues",
            endpoint="/jira/query",
            payload={"query": "list all jira issues"},
            expected_fields=["response", "success"]
        ),
        TestCase(
            name="JIRA-2: List Issues in TEST Project",
            endpoint="/jira/query",
            payload={"query": "show me all issues in TEST project"},
            expected_fields=["response", "success"]
        ),
        TestCase(
            name="JIRA-3: Find Issues by Assignee",
            endpoint="/jira/query",
            payload={"query": "list all issues assigned to Kiet Ho"},
            expected_fields=["response", "success"]
        ),
        TestCase(
            name="JIRA-4: Find Issues by Keyword",
            endpoint="/jira/query",
            payload={"query": "find all issues related to Alarm"},
            expected_fields=["response", "success"]
        ),
        TestCase(
            name="JIRA-5: Get Issue Details",
            endpoint="/jira/query",
            payload={"query": "get details of issue TEST-1"},
            expected_fields=["response", "success"]
        ),
        TestCase(
            name="JIRA-6: List Open Issues",
            endpoint="/jira/query",
            payload={"query": "show all open issues in TEST project"},
            expected_fields=["response", "success"]
        )
    ]
    
    for test in tests:
        result = await run_test(test)
        test_results.append(result)
        print_test_result(result)


async def test_supervisor_agent():
    """Test Supervisor Agent routing logic"""
    print_header("SUPERVISOR AGENT TESTS")
    
    tests = [
        TestCase(
            name="SUP-1: Pure RAG Query",
            endpoint="/supervisor",
            payload={"query": "what is TMA solution?"},
            expected_fields=["response", "rag_response", "execution_log", "success"]
        ),
        TestCase(
            name="SUP-2: Pure Jira Query",
            endpoint="/supervisor",
            payload={"query": "list all jira issues in TEST project"},
            expected_fields=["response", "jira_response", "execution_log", "success"]
        ),
        TestCase(
            name="SUP-3: Hybrid Query (Both Agents)",
            endpoint="/supervisor",
            payload={"query": "create a jira ticket based on TMA solution documentation"},
            expected_fields=["response", "rag_response", "jira_response", "execution_log", "success"]
        ),
        TestCase(
            name="SUP-4: Document + Ticket Creation",
            endpoint="/supervisor",
            payload={"query": "find information about Alarm feature and create a ticket to implement it"},
            expected_fields=["response", "execution_log", "success"]
        ),
        TestCase(
            name="SUP-5: Ambiguous Query (Router Decision)",
            endpoint="/supervisor",
            payload={"query": "what are the current issues?"},
            expected_fields=["response", "execution_log", "success"]
        )
    ]
    
    for test in tests:
        result = await run_test(test)
        test_results.append(result)
        print_test_result(result)


async def test_edge_cases():
    """Test edge cases and error handling"""
    print_header("EDGE CASES & ERROR HANDLING")
    
    tests = [
        TestCase(
            name="EDGE-1: Empty Query",
            endpoint="/rag",
            payload={"question": ""},
            expected_fields=["error"]
        ),
        TestCase(
            name="EDGE-2: Very Long Query",
            endpoint="/rag",
            payload={"question": "tell me everything about " + "network management " * 50},
            expected_fields=["answer"]
        ),
        TestCase(
            name="EDGE-3: Special Characters in Query",
            endpoint="/jira/query",
            payload={"query": "issues with @#$%^&* special chars"},
            expected_fields=["response"]
        ),
        TestCase(
            name="EDGE-4: Non-existent Jira Issue",
            endpoint="/jira/query",
            payload={"query": "get details of issue NONEXISTENT-99999"},
            expected_fields=["response"]
        ),
        TestCase(
            name="EDGE-5: Multiple Questions",
            endpoint="/supervisor",
            payload={"query": "What is TMA? Also list all jira issues. And tell me about Docker."},
            expected_fields=["response"]
        )
    ]
    
    for test in tests:
        result = await run_test(test)
        test_results.append(result)
        print_test_result(result)


async def test_performance():
    """Test performance with concurrent requests"""
    print_header("PERFORMANCE TESTS")
    
    print("\n▶ Running: Concurrent RAG Queries")
    start_time = datetime.now()
    
    tasks = [
        run_test(TestCase(
            name=f"PERF-RAG-{i}",
            endpoint="/rag",
            payload={"question": f"What is information about topic {i}?"},
            expected_fields=["answer"]
        ))
        for i in range(3)
    ]
    
    results = await asyncio.gather(*tasks)
    duration = (datetime.now() - start_time).total_seconds()
    
    passed = sum(1 for r in results if r.passed)
    print(f"✅ Completed {passed}/{len(results)} concurrent RAG queries in {duration:.2f}s")
    test_results.extend(results)
    
    print("\n▶ Running: Concurrent Jira Queries")
    start_time = datetime.now()
    
    tasks = [
        run_test(TestCase(
            name=f"PERF-JIRA-{i}",
            endpoint="/jira/query",
            payload={"query": "list issues in TEST project"},
            expected_fields=["response"]
        ))
        for i in range(3)
    ]
    
    results = await asyncio.gather(*tasks)
    duration = (datetime.now() - start_time).total_seconds()
    
    passed = sum(1 for r in results if r.passed)
    print(f"✅ Completed {passed}/{len(results)} concurrent Jira queries in {duration:.2f}s")
    test_results.extend(results)


def print_summary():
    """Print test summary"""
    print_header("TEST SUMMARY")
    
    total = len(test_results)
    passed = sum(1 for t in test_results if t.passed)
    failed = total - passed
    
    print(f"\nTotal Tests: {total}")
    print(f"✅ Passed: {passed} ({passed/total*100:.1f}%)")
    print(f"❌ Failed: {failed} ({failed/total*100:.1f}%)")
    
    total_duration = sum(t.duration for t in test_results)
    avg_duration = total_duration / total if total > 0 else 0
    print(f"\nTotal Duration: {total_duration:.2f}s")
    print(f"Average Duration: {avg_duration:.2f}s")
    
    if failed > 0:
        print("\n" + "=" * 80)
        print("  FAILED TESTS")
        print("=" * 80)
        for test in test_results:
            if not test.passed:
                print(f"\n❌ {test.name}")
                print(f"   Endpoint: {test.endpoint}")
                print(f"   Error: {test.error}")
    
    # Category breakdown
    print("\n" + "=" * 80)
    print("  RESULTS BY CATEGORY")
    print("=" * 80)
    
    categories = {
        "RAG": [t for t in test_results if t.name.startswith("RAG-")],
        "JIRA": [t for t in test_results if t.name.startswith("JIRA-")],
        "SUPERVISOR": [t for t in test_results if t.name.startswith("SUP-")],
        "EDGE CASES": [t for t in test_results if t.name.startswith("EDGE-")],
        "PERFORMANCE": [t for t in test_results if t.name.startswith("PERF-")]
    }
    
    for category, tests in categories.items():
        if tests:
            cat_passed = sum(1 for t in tests if t.passed)
            cat_total = len(tests)
            status = "✅" if cat_passed == cat_total else "⚠️"
            print(f"{status} {category}: {cat_passed}/{cat_total} passed")


async def main():
    """Run all test suites"""
    print("\n" + "🚀" * 40)
    print("  MULTI-AGENT SYSTEM - COMPREHENSIVE TEST SUITE")
    print("🚀" * 40)
    print(f"\nBackend URL: {BASE_URL}")
    print(f"Start Time: {datetime.now().isoformat()}")
    
    # Check if server is running
    try:
        async with httpx.AsyncClient(timeout=5.0) as client:
            response = await client.get(f"{BASE_URL}/")
            print(f"✅ Server is running (HTTP {response.status_code})")
    except Exception as e:
        print(f"❌ Cannot connect to server: {e}")
        print("   Please start the server with: python src/main.py")
        return
    
    # Run test suites
    await test_rag_agent()
    await test_jira_agent()
    await test_supervisor_agent()
    await test_edge_cases()
    await test_performance()
    
    # Print summary
    print_summary()
    
    print("\n" + "🎯" * 40)
    print(f"  TEST SUITE COMPLETED")
    print(f"  End Time: {datetime.now().isoformat()}")
    print("🎯" * 40 + "\n")
    
    # Save results to JSON
    results_file = "test_results.json"
    with open(results_file, 'w') as f:
        json.dump([
            {
                "name": t.name,
                "endpoint": t.endpoint,
                "payload": t.payload,
                "passed": t.passed,
                "duration": t.duration,
                "error": t.error
            }
            for t in test_results
        ], f, indent=2)
    print(f"📄 Detailed results saved to: {results_file}\n")


if __name__ == "__main__":
    asyncio.run(main())
