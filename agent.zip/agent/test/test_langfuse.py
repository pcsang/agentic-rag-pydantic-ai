#!/usr/bin/env python3
"""
Test script for Langfuse observability integration

This script tests the Langfuse tracing setup by running a sample RAG query
and verifying that traces are properly sent to your local Langfuse instance.

Usage:
    python test_langfuse.py

Prerequisites:
    - Langfuse running on http://localhost:3000
    - Environment variables configured (see .env.example)
    - OpenAI API key for LLM calls
"""

import asyncio
import os
import sys
from pathlib import Path

# Add src to path
sys.path.insert(0, str(Path(__file__).parent / 'src'))

from dotenv import load_dotenv

async def main():
    """Main test function"""
    
    # Load environment variables
    env_path = Path(__file__).parent / '.env'
    if env_path.exists():
        load_dotenv(env_path)
    else:
        print(f"⚠️  .env file not found at {env_path}, trying default...")
    
    print("\n" + "="*70)
    print("LANGFUSE OBSERVABILITY TEST")
    print("="*70 + "\n")
    
    # Check environment
    print("1️⃣  Checking configuration...")
    langfuse_public_key = os.getenv('LANGFUSE_PUBLIC_KEY')
    langfuse_secret_key = os.getenv('LANGFUSE_SECRET_KEY')
    langfuse_host = os.getenv('LANGFUSE_HOST', 'http://localhost:3000')
    openai_key = os.getenv('OPENAI_API_KEY')
    
    missing_vars = []
    if not langfuse_public_key:
        missing_vars.append("LANGFUSE_PUBLIC_KEY")
    if not langfuse_secret_key:
        missing_vars.append("LANGFUSE_SECRET_KEY")
    if not openai_key:
        missing_vars.append("OPENAI_API_KEY")
    
    if missing_vars:
        print(f"❌ Missing environment variables: {', '.join(missing_vars)}")
        print("\nPlease add to .env file:")
        for var in missing_vars:
            print(f"  {var}=your_value_here")
        return False
    
    print(f"✅ Configuration found")
    print(f"   - Langfuse Host: {langfuse_host}")
    print(f"   - Public Key: {langfuse_public_key[:20]}...")
    print(f"   - OpenAI API: Available")
    
    # Check Langfuse availability
    print("\n2️⃣  Checking Langfuse availability...")
    try:
        import httpx
        async with httpx.AsyncClient(timeout=5.0) as client:
            response = await client.get(f"{langfuse_host}/api/health")
            if response.status_code == 200:
                print(f"✅ Langfuse is accessible at {langfuse_host}")
            else:
                print(f"⚠️  Langfuse responded with status {response.status_code}")
    except Exception as e:
        print(f"⚠️  Could not connect to Langfuse: {e}")
        print(f"    Make sure Langfuse is running at {langfuse_host}")
        print(f"    Start with: docker-compose up -d")
    
    # Check Langfuse import
    print("\n3️⃣  Checking Langfuse SDK...")
    try:
        from langfuse import observe, get_client
        print("✅ Langfuse SDK is installed")
        
        # Try to initialize client
        langfuse_client = get_client()
        print("✅ Langfuse client initialized successfully")
    except ImportError:
        print("❌ Langfuse SDK not installed")
        print("   Install with: pip install langfuse")
        return False
    except Exception as e:
        print(f"⚠️  Could not initialize Langfuse client: {e}")
    
    # Import and test RAG agent
    print("\n4️⃣  Testing RAG agent...")
    try:
        from rag_agent import query_rag_system, LANGFUSE_AVAILABLE
        print(f"✅ RAG agent imported successfully")
        print(f"   - Langfuse Available: {LANGFUSE_AVAILABLE}")
        
    except Exception as e:
        print(f"❌ Failed to import RAG agent: {e}")
        return False
    
    # Run a test query
    print("\n5️⃣  Running test RAG query...")
    print("   Query: 'What is RAG (Retrieval-Augmented Generation)?'\n")
    
    try:
        response = await query_rag_system("What is RAG (Retrieval-Augmented Generation)?")
        
        print("✅ RAG query completed successfully!")
        print(f"   - Strategy used: {response.strategy_used}")
        print(f"   - Agent workflow: {' → '.join(response.agent_workflow)}")
        print(f"   - Iterations: {response.iterations}")
        print(f"   - Sources: {len(response.sources)}")
        
        if response.grading:
            print(f"   - Quality scores:")
            print(f"     • Relevancy: {response.grading.relevancy:.2f}")
            print(f"     • Faithfulness: {response.grading.faithfulness:.2f}")
            print(f"     • Context Quality: {response.grading.context_quality:.2f}")
        
        # Flush to ensure traces are sent
        print("\n6️⃣  Flushing traces...")
        try:
            langfuse_client.flush()
            print("✅ Traces flushed successfully")
        except Exception as e:
            print(f"⚠️  Could not flush traces: {e}")
        
        print("\n" + "="*70)
        print("✅ TEST COMPLETED SUCCESSFULLY!")
        print("="*70)
        print(f"\n📊 View your traces at: {langfuse_host}/traces")
        print("   Look for traces with the following names:")
        print("   - rag-query")
        print("   - router-assess-local")
        print("   - router-decide-strategy")
        print("   - local-retriever")
        print("   - generator-agent")
        print("   - grader-agent")
        
        return True
        
    except Exception as e:
        print(f"❌ RAG query failed: {e}")
        import traceback
        traceback.print_exc()
        return False

if __name__ == "__main__":
    success = asyncio.run(main())
    sys.exit(0 if success else 1)