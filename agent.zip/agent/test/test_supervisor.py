#!/usr/bin/env python3
"""
Test Supervisor Agent with Multiple Queries
"""
import asyncio
import sys
import os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'src'))

# Disable OpenTelemetry to avoid 404 errors
os.environ['OTEL_SDK_DISABLED'] = 'true'

async def test_supervisor():
    """Test supervisor agent with different query types"""
    from supervisor_agent import supervisor_query
    
    test_cases = [
        {
            "name": "RAG Query - Document Information",
            "query": "tell me information about TMA solution",
            "expected": "rag"
        },
        {
            "name": "Jira Query - List Issues",
            "query": "list all jira issues in TEST project",
            "expected": "jira"
        },
        {
            "name": "Hybrid Query - Both Agents",
            "query": "create a jira ticket based on the TMA solution documentation",
            "expected": "both"
        },
        {
            "name": "General Knowledge",
            "query": "what is Python programming language?",
            "expected": "rag"
        }
    ]
    
    print("🎯 SUPERVISOR AGENT TEST SUITE")
    print("=" * 80)
    
    for i, test_case in enumerate(test_cases, 1):
        print(f"\n{'='*80}")
        print(f"Test {i}/{len(test_cases)}: {test_case['name']}")
        print(f"Query: {test_case['query']}")
        print(f"Expected: {test_case['expected']} agent(s)")
        print('='*80)
        
        try:
            result = await supervisor_query(test_case['query'])
            
            print("\n📋 EXECUTION LOG:")
            for msg in result['execution_log']:
                print(f"   {msg}")
            
            print(f"\n✅ SUCCESS: {result['success']}")
            
            if result.get('rag_response'):
                print(f"\n📚 RAG Response ({len(result['rag_response'])} chars)")
                print(f"   {result['rag_response'][:200]}...")
            
            if result.get('jira_response'):
                print(f"\n🎫 Jira Response ({len(result['jira_response'])} chars)")
                print(f"   {result['jira_response'][:200]}...")
            
            print(f"\n📝 FINAL RESPONSE:")
            print(f"   {result['response'][:300]}...")
            
        except Exception as e:
            print(f"\n❌ TEST FAILED: {e}")
            import traceback
            traceback.print_exc()
    
    print("\n" + "="*80)
    print("✅ ALL TESTS COMPLETED")
    print("="*80)

if __name__ == "__main__":
    asyncio.run(test_supervisor())
