#!/usr/bin/env python3
"""
Simple test of router decision making for LLM fallback
"""
import asyncio
import sys
from pathlib import Path

# Add src to path
src_path = Path(__file__).parent / "src"
sys.path.insert(0, str(src_path))

# Load environment
from dotenv import load_dotenv
env_path = Path(__file__).parent / ".env"
load_dotenv(env_path)

from rag_agent import decide_rag_strategy, is_conversational_query
from rag_agent import LocalRAGAssessment, AgentAction, AgentRole

async def test_router_decisions():
    """Test router decision making for conversational vs non-conversational queries"""
    
    test_cases = [
        "Hello",
        "Hi there",
        "How are you?", 
        "What can you do?",
        "Thanks",
        "What is Docker?",
        "How do I install Python?",
    ]
    
    print("🧪 Testing Router Decision Making")
    print("=" * 50)
    
    for query in test_cases:
        print(f"\n🔍 Query: '{query}'")
        
        # Test conversational detection first
        is_conv = is_conversational_query(query)
        print(f"   Conversational: {is_conv}")
        
        # Create a dummy local assessment (simulating no local info)
        assessment = LocalRAGAssessment(
            has_info=False,
            info_quality="none",
            confidence_score=0.0,
            temporal_keywords_detected=False,
            reasoning="No local info found for testing",
            suggested_action=AgentAction(
                action="use_web_search",
                parameters={},
                reasoning="No local info"
            )
        )
        
        # Test router decision
        decision = await decide_rag_strategy(assessment, query)
        print(f"   Strategy: {decision.strategy}")
        print(f"   Reasoning: {decision.reasoning}")
        print(f"   Next Agent: {decision.next_agent.value}")
        
        # Check if routing is correct
        expected_strategy = "llm_fallback" if is_conv else "web_only"
        if decision.strategy == expected_strategy:
            print("   ✅ Correct routing!")
        else:
            print(f"   ❌ Wrong routing! Expected: {expected_strategy}")

if __name__ == "__main__":
    asyncio.run(test_router_decisions())