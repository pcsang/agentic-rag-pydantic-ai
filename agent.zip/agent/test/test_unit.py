#!/usr/bin/env python3
"""
Unit Tests for Individual Agent Components
Tests each agent in isolation without requiring full server
"""
import asyncio
import sys
import os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'src'))

# Disable OpenTelemetry to avoid 404 errors
os.environ['OTEL_SDK_DISABLED'] = 'true'


async def test_rag_agent_unit():
    """Test RAG agent directly"""
    print("\n" + "=" * 80)
    print("  UNIT TEST: RAG AGENT")
    print("=" * 80)
    
    from rag_agent import handle_query
    
    test_cases = [
        {
            "name": "Local document query",
            "query": "tell me about TMA solution",
            "expect_sources": True
        },
        {
            "name": "Web search query",
            "query": "latest Docker version 2025",
            "expect_sources": True
        },
        {
            "name": "Technical documentation",
            "query": "what is network alarm management?",
            "expect_sources": True
        }
    ]
    
    results = {"passed": 0, "failed": 0}
    
    for test in test_cases:
        print(f"\n▶ Test: {test['name']}")
        print(f"  Query: {test['query']}")
        
        try:
            result = await handle_query(test['query'])
            
            # Validate response structure
            assert 'answer' in result, "Missing 'answer' field"
            assert 'sources' in result, "Missing 'sources' field"
            assert 'strategy' in result, "Missing 'strategy' field"
            
            if test['expect_sources']:
                assert len(result['sources']) > 0, "Expected sources but got none"
            
            print(f"  ✅ PASS")
            print(f"     Strategy: {result.get('strategy', 'unknown')}")
            print(f"     Sources: {len(result.get('sources', []))}")
            print(f"     Answer length: {len(result.get('answer', ''))}")
            results["passed"] += 1
            
        except AssertionError as e:
            print(f"  ❌ FAIL: {e}")
            results["failed"] += 1
        except Exception as e:
            print(f"  ❌ ERROR: {e}")
            results["failed"] += 1
    
    return results


async def test_jira_agent_unit():
    """Test Jira agent directly"""
    print("\n" + "=" * 80)
    print("  UNIT TEST: JIRA AGENT")
    print("=" * 80)
    
    from jira_agent import jira_agent
    
    test_cases = [
        {
            "name": "List all issues",
            "query": "list all jira issues"
        },
        {
            "name": "List issues in TEST project",
            "query": "show issues in TEST project"
        },
        {
            "name": "Find issues by assignee",
            "query": "find issues assigned to Kiet Ho"
        }
    ]
    
    results = {"passed": 0, "failed": 0}
    
    for test in test_cases:
        print(f"\n▶ Test: {test['name']}")
        print(f"  Query: {test['query']}")
        
        try:
            result = await jira_agent.run(test['query'])
            
            # Validate response
            response = result.data if hasattr(result, 'data') else str(result)
            assert response is not None, "Got None response"
            assert len(str(response)) > 0, "Got empty response"
            
            print(f"  ✅ PASS")
            print(f"     Response length: {len(str(response))}")
            results["passed"] += 1
            
        except AssertionError as e:
            print(f"  ❌ FAIL: {e}")
            results["failed"] += 1
        except Exception as e:
            print(f"  ❌ ERROR: {e}")
            results["failed"] += 1
    
    return results


async def test_supervisor_unit():
    """Test supervisor agent routing"""
    print("\n" + "=" * 80)
    print("  UNIT TEST: SUPERVISOR AGENT")
    print("=" * 80)
    
    from supervisor_agent import supervisor_query
    
    test_cases = [
        {
            "name": "RAG-only query",
            "query": "what is TMA solution?",
            "expect_rag": True,
            "expect_jira": False
        },
        {
            "name": "Jira-only query",
            "query": "list all jira issues",
            "expect_rag": False,
            "expect_jira": True
        },
        {
            "name": "Hybrid query",
            "query": "create a ticket based on TMA documentation",
            "expect_rag": True,
            "expect_jira": True
        }
    ]
    
    results = {"passed": 0, "failed": 0}
    
    for test in test_cases:
        print(f"\n▶ Test: {test['name']}")
        print(f"  Query: {test['query']}")
        
        try:
            result = await supervisor_query(test['query'])
            
            # Validate response structure
            assert 'response' in result, "Missing 'response' field"
            assert 'success' in result, "Missing 'success' field"
            assert 'execution_log' in result, "Missing 'execution_log' field"
            
            # Check routing expectations
            if test['expect_rag']:
                assert result.get('rag_response') is not None, "Expected RAG response but got None"
            
            if test['expect_jira']:
                assert result.get('jira_response') is not None, "Expected Jira response but got None"
            
            print(f"  ✅ PASS")
            print(f"     RAG used: {result.get('rag_response') is not None}")
            print(f"     Jira used: {result.get('jira_response') is not None}")
            print(f"     Execution steps: {len(result.get('execution_log', []))}")
            results["passed"] += 1
            
        except AssertionError as e:
            print(f"  ❌ FAIL: {e}")
            results["failed"] += 1
        except Exception as e:
            print(f"  ❌ ERROR: {e}")
            results["failed"] += 1
    
    return results


async def test_router_logic():
    """Test router agent decision making"""
    print("\n" + "=" * 80)
    print("  UNIT TEST: ROUTER LOGIC")
    print("=" * 80)
    
    from supervisor_agent import router_agent
    
    test_cases = [
        {
            "name": "Clear RAG query",
            "query": "explain network management systems",
            "expect_rag": True
        },
        {
            "name": "Clear Jira query",
            "query": "show me all open tickets",
            "expect_jira": True
        },
        {
            "name": "Document + ticket creation",
            "query": "create a jira issue for implementing the alarm feature",
            "expect_both": True
        }
    ]
    
    results = {"passed": 0, "failed": 0}
    
    for test in test_cases:
        print(f"\n▶ Test: {test['name']}")
        print(f"  Query: {test['query']}")
        
        try:
            result = await router_agent.run(
                f"Analyze this query and decide which agent(s) to use: {test['query']}"
            )
            
            decision = result.output
            
            # Validate decision structure
            assert hasattr(decision, 'use_rag'), "Missing use_rag field"
            assert hasattr(decision, 'use_jira'), "Missing use_jira field"
            assert hasattr(decision, 'reasoning'), "Missing reasoning field"
            
            # Check expectations
            if test.get('expect_rag'):
                assert decision.use_rag, f"Expected use_rag=True but got False"
            
            if test.get('expect_jira'):
                assert decision.use_jira, f"Expected use_jira=True but got False"
            
            if test.get('expect_both'):
                assert decision.use_rag and decision.use_jira, "Expected both agents"
            
            print(f"  ✅ PASS")
            print(f"     Decision: RAG={decision.use_rag}, Jira={decision.use_jira}")
            print(f"     Reasoning: {decision.reasoning}")
            results["passed"] += 1
            
        except AssertionError as e:
            print(f"  ❌ FAIL: {e}")
            results["failed"] += 1
        except Exception as e:
            print(f"  ❌ ERROR: {e}")
            results["failed"] += 1
    
    return results


async def main():
    """Run all unit tests"""
    print("\n" + "🧪" * 40)
    print("  MULTI-AGENT SYSTEM - UNIT TEST SUITE")
    print("🧪" * 40)
    
    all_results = {
        "passed": 0,
        "failed": 0,
        "total": 0
    }
    
    # Run test suites
    test_suites = [
        ("RAG Agent", test_rag_agent_unit),
        ("Jira Agent", test_jira_agent_unit),
        ("Supervisor Agent", test_supervisor_unit),
        ("Router Logic", test_router_logic)
    ]
    
    for suite_name, test_func in test_suites:
        try:
            results = await test_func()
            all_results["passed"] += results["passed"]
            all_results["failed"] += results["failed"]
        except Exception as e:
            print(f"\n❌ Test suite '{suite_name}' crashed: {e}")
            import traceback
            traceback.print_exc()
    
    # Print summary
    all_results["total"] = all_results["passed"] + all_results["failed"]
    
    print("\n" + "=" * 80)
    print("  UNIT TEST SUMMARY")
    print("=" * 80)
    print(f"\nTotal Tests: {all_results['total']}")
    print(f"✅ Passed: {all_results['passed']}")
    print(f"❌ Failed: {all_results['failed']}")
    
    if all_results['total'] > 0:
        pass_rate = (all_results['passed'] / all_results['total']) * 100
        print(f"Pass Rate: {pass_rate:.1f}%")
    
    print("\n" + "🎯" * 40)
    print("  UNIT TESTS COMPLETED")
    print("🎯" * 40 + "\n")
    
    return all_results['failed'] == 0


if __name__ == "__main__":
    success = asyncio.run(main())
    sys.exit(0 if success else 1)
