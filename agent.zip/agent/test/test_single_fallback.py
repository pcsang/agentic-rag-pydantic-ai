#!/usr/bin/env python3
"""
Single end-to-end test of LLM fallback
"""
import asyncio
import sys
from pathlib import Path

# Add src to path
src_path = Path(__file__).parent / "src"
sys.path.insert(0, str(src_path))

# Load environment
from dotenv import load_dotenv
env_path = Path(__file__).parent / ".env"
load_dotenv(env_path)

from rag_agent import query_rag_system

async def test_single_fallback():
    """Test a single conversational query end-to-end"""
    
    query = "Hello"
    
    print(f"🧪 Testing End-to-End LLM Fallback")
    print(f"Query: '{query}'")
    print("=" * 50)
    
    try:
        result = await query_rag_system(query)
        
        print(f"✅ Strategy Used: {result.strategy_used}")
        print(f"✅ Agent Workflow: {' → '.join(result.agent_workflow)}")
        print(f"✅ Sources Count: {len(result.sources)}")
        print(f"✅ Used Web Search: {result.used_web_search}")
        
        print(f"\n📝 Answer Preview:")
        answer_preview = result.answer[:200] + "..." if len(result.answer) > 200 else result.answer
        print(answer_preview)
        
        # Verify it's the expected fallback behavior
        if result.strategy_used == "llm_fallback" and len(result.sources) == 0 and not result.used_web_search:
            print(f"\n🎉 SUCCESS: LLM Fallback working correctly!")
        else:
            print(f"\n❌ ISSUE: Unexpected behavior")
            print(f"   Expected: strategy=llm_fallback, sources=0, web_search=False")
            print(f"   Got: strategy={result.strategy_used}, sources={len(result.sources)}, web_search={result.used_web_search}")
        
    except Exception as e:
        print(f"❌ Error: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    asyncio.run(test_single_fallback())