#!/usr/bin/env python3
"""
Simple test of conversational query detection
"""
import sys
from pathlib import Path

# Add src to path
src_path = Path(__file__).parent / "src"
sys.path.insert(0, str(src_path))

from rag_agent import is_conversational_query

def test_conversational_detection():
    """Test the is_conversational_query function"""
    
    test_cases = [
        # Should be conversational (True)
        ("Hello", True),
        ("Hi", True),
        ("Hey", True),
        ("Good morning", True),
        ("How are you?", True),
        ("Who are you?", True),
        ("What can you do?", True),
        ("Can you help?", True),
        ("Thank you", True),
        ("Thanks", True),
        
        # Should NOT be conversational (False)
        ("What is Docker?", False),
        ("How do I install Python?", False),
        ("TMA Solutions company information", False),
        ("Explain machine learning", False),
        ("Configure Kubernetes", False),
    ]
    
    print("🧪 Testing Conversational Query Detection")
    print("=" * 50)
    
    correct = 0
    total = len(test_cases)
    
    for query, expected in test_cases:
        result = is_conversational_query(query)
        status = "✅" if result == expected else "❌"
        
        print(f"{status} '{query}' -> {result} (expected: {expected})")
        
        if result == expected:
            correct += 1
    
    print(f"\n📊 Results: {correct}/{total} correct ({correct/total*100:.1f}%)")
    
    if correct == total:
        print("✅ All tests passed!")
    else:
        print(f"❌ {total - correct} tests failed")

if __name__ == "__main__":
    test_conversational_detection()