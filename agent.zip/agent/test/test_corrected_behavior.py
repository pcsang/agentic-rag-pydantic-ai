#!/usr/bin/env python3
"""
Test the corrected LLM fallback implementation that maintains original behavior
"""
import asyncio
import sys
from pathlib import Path

# Add src to path
src_path = Path(__file__).parent / "src"
sys.path.insert(0, str(src_path))

# Load environment
from dotenv import load_dotenv
env_path = Path(__file__).parent / ".env"
load_dotenv(env_path)

from rag_agent import query_rag_system

async def test_corrected_behavior():
    """Test that the corrected implementation maintains proper behavior"""
    
    test_cases = [
        ("Hello", "Should be LLM_FALLBACK, but with proper assessment flow"),
        ("steps to set deployment profile in SO Docker", "Should be WEB_ONLY with full original workflow")
    ]
    
    for query, expected_behavior in test_cases:
        print(f"🧪 Testing Corrected Implementation")
        print(f"Query: '{query}'")
        print(f"Expected: {expected_behavior}")
        print("=" * 60)
        
        try:
            result = await query_rag_system(query)
            
            print(f"✅ Strategy: {result.strategy_used}")
            print(f"✅ Workflow: {' → '.join(result.agent_workflow)}")
            print(f"✅ Sources: {len(result.sources)}")
            print(f"✅ Web Search: {result.used_web_search}")
            
            # Check local assessment (should never be None now)
            if result.local_assessment:
                print(f"✅ Local Assessment: {result.local_assessment.info_quality}")
            else:
                print(f"❌ Local Assessment: None (This is a problem!)")
            
            # Verify no breaking changes
            if query == "Hello":
                if result.strategy_used == "llm_fallback" and result.local_assessment is not None:
                    print(f"🎉 SUCCESS: Conversational query with proper assessment!")
                else:
                    print(f"❌ Issue: Missing assessment or wrong strategy")
            else:
                if result.strategy_used in ["web_only", "local_only"] and len(result.sources) > 0:
                    print(f"🎉 SUCCESS: Technical query handled correctly!")
                elif result.strategy_used in ["web_only", "local_only"] and len(result.sources) == 0:
                    print(f"⚠️  Note: No sources found, but routing is correct")
                else:
                    print(f"❌ Issue: Unexpected behavior for technical query")
            
            print(f"\n📝 Answer Preview:")
            preview = result.answer[:150] + "..." if len(result.answer) > 150 else result.answer
            print(preview)
            
        except Exception as e:
            print(f"❌ Error: {e}")
            import traceback
            traceback.print_exc()
        
        print(f"\n" + "="*60 + "\n")

if __name__ == "__main__":
    asyncio.run(test_corrected_behavior())