#!/usr/bin/env python3
"""
Test the specific query that's showing incorrect workflow
"""
import asyncio
import sys
from pathlib import Path

# Add src to path
src_path = Path(__file__).parent / "src"
sys.path.insert(0, str(src_path))

# Load environment
from dotenv import load_dotenv
env_path = Path(__file__).parent / ".env"
load_dotenv(env_path)

from rag_agent import is_conversational_query, decide_rag_strategy, query_rag_system
from rag_agent import LocalRAGAssessment, AgentAction

async def test_docker_query():
    """Test the specific Docker deployment query"""
    
    query = "steps to set deployment profile in SO Docker ?"
    
    print(f"🧪 Testing Docker Query Routing")
    print(f"Query: '{query}'")
    print("=" * 60)
    
    # Test conversational detection
    is_conv = is_conversational_query(query)
    print(f"📋 Conversational Detection: {is_conv}")
    
    if is_conv:
        print("❌ ISSUE: Technical query detected as conversational!")
        print("   This should be False for technical queries about Docker")
    else:
        print("✅ Correct: Technical query not detected as conversational")
    
    # Test full workflow
    print(f"\n🔄 Testing Full RAG Workflow:")
    try:
        result = await query_rag_system(query)
        
        print(f"Strategy Used: {result.strategy_used}")
        print(f"Agent Workflow: {' → '.join(result.agent_workflow)}")
        print(f"Sources Count: {len(result.sources)}")
        print(f"Used Web Search: {result.used_web_search}")
        
        # Check if routing is appropriate for technical query
        if result.strategy_used == "llm_fallback":
            print("❌ PROBLEM: Technical Docker query routed to LLM fallback!")
            print("   Expected: web_only or local_only or generate_grade_augment")
        elif result.strategy_used in ["web_only", "local_only", "generate_grade_augment"]:
            print("✅ Correct: Technical query routed appropriately")
        else:
            print(f"❓ Unexpected strategy: {result.strategy_used}")
        
        print(f"\n📝 Answer Preview:")
        answer_preview = result.answer[:300] + "..." if len(result.answer) > 300 else result.answer
        print(answer_preview)
        
    except Exception as e:
        print(f"❌ Error: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    asyncio.run(test_docker_query())