#!/usr/bin/env python3
"""
Direct test of RAG agent source formatting
"""
import asyncio
import sys
import os
from pathlib import Path

# Add src to path
src_path = Path(__file__).parent / "src"
sys.path.insert(0, str(src_path))

# Load environment
from dotenv import load_dotenv
env_path = Path(__file__).parent / ".env"
load_dotenv(env_path)

from rag_agent import handle_query

async def test_source_formatting():
    print("🧪 Testing RAG agent source formatting...")
    print("=" * 60)
    
    # Test query about TMA Solutions
    query = "Tell me about TMA Solutions company in Vietnam"
    print(f"Query: {query}")
    print("-" * 60)
    
    try:
        result = await handle_query(query)
        
        print("📝 ANSWER:")
        print(result['answer'])
        print("\n" + "=" * 60)
        
        print("📚 EXTRACTED SOURCES:")
        for i, source in enumerate(result['sources'], 1):
            print(f"{i}. {source}")
        
        print("\n" + "=" * 60)
        print("✅ Test completed successfully!")
        
        # Check if answer contains placeholder text
        answer_text = result['answer']
        problematic_patterns = ['[source]', '[source, source]', '*source*', '[Source 1]']
        
        print("\n🔍 SOURCE PATTERN ANALYSIS:")
        for pattern in problematic_patterns:
            if pattern in answer_text:
                print(f"❌ Found problematic pattern: {pattern}")
            else:
                print(f"✅ No problematic pattern: {pattern}")
        
        # Check for proper URL formatting
        import re
        url_pattern = r'\[([^\]]+)\]\(https?://[^\)]+\)'
        url_matches = re.findall(url_pattern, answer_text)
        if url_matches:
            print(f"\n✅ Found {len(url_matches)} properly formatted URL citations:")
            for match in url_matches:
                print(f"   - [{match}](...)")
        else:
            print("\n⚠️  No properly formatted URL citations found")
        
    except Exception as e:
        print(f"❌ Test failed: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    asyncio.run(test_source_formatting())