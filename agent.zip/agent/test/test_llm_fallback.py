#!/usr/bin/env python3
"""
Test script for LLM fallback functionality in RAG agent
"""
import asyncio
import sys
import os
from pathlib import Path

# Add src to path
src_path = Path(__file__).parent / "src"
sys.path.insert(0, str(src_path))

# Load environment
from dotenv import load_dotenv
env_path = Path(__file__).parent / ".env"
load_dotenv(env_path)

from rag_agent import handle_query

async def test_llm_fallback():
    """Test various conversational queries to ensure they route to LLM fallback"""
    
    test_cases = [
        # Greetings
        "Hello",
        "Hi there",
        "Hey",
        "Good morning",
        
        # Conversational questions
        "How are you?",
        "What's up?",
        "Who are you?",
        "What can you do?",
        
        # General assistance
        "Can you help me?",
        "I need help",
        "Help",
        
        # Politeness
        "Thank you",
        "Thanks",
        
        # Contrast with technical queries
        "What is Docker?",  # Should go to web/local search
        "How do I install Python?",  # Should go to web/local search
    ]
    
    print("🧪 Testing LLM Fallback Routing")
    print("=" * 60)
    
    for i, query in enumerate(test_cases, 1):
        print(f"\n{i}. Testing: '{query}'")
        print("-" * 40)
        
        try:
            result = await handle_query(query)
            
            # Check which strategy was used
            strategy = result.get('strategy', 'unknown')
            workflow = result.get('agent_workflow', [])
            sources_count = len(result.get('sources', []))
            
            print(f"Strategy: {strategy}")
            print(f"Workflow: {' → '.join(workflow)}")
            print(f"Sources: {sources_count}")
            
            # Analyze if routing was correct
            is_conversational = any(word in query.lower() for word in [
                'hello', 'hi', 'hey', 'how are you', 'what\'s up', 'who are you',
                'what can you do', 'help me', 'thank you', 'thanks'
            ])
            
            expected_strategy = 'llm_fallback' if is_conversational else 'web_only'
            
            if strategy == expected_strategy:
                print("✅ Correct routing!")
            else:
                print(f"❌ Unexpected routing! Expected: {expected_strategy}, Got: {strategy}")
            
            # Show first part of answer
            answer = result.get('answer', '')
            preview = answer[:100] + '...' if len(answer) > 100 else answer
            print(f"Answer preview: {preview}")
            
        except Exception as e:
            print(f"❌ Error: {e}")
    
    print(f"\n{'='*60}")
    print("✅ LLM Fallback testing completed!")

if __name__ == "__main__":
    asyncio.run(test_llm_fallback())