import asyncio
from langchain_mcp_adapters.client import MultiServerMCPClient
 
async def check_sessions():
    try:
        client = MultiServerMCPClient({
            "jira": {
                "url": "http://mcp-atlassian:9000/mcp/",
                "transport": "streamable_http",
            }
        })
        print("Created client, opening session...")
        async with client.session("jira") as session:
            print("✅ Opened session with JIRA server")
            if hasattr(session, 'call_tool'):
                print("✅ session has call_tool method!")
                result = await session.call_tool("jira_search", {
                    "jql": "assignee = \"Kiet Ho\" AND project = TEST",
                    "fields": "summary,status,priority",
                    "limit": 50
                })
                print(f"  ✅ call_tool worked! Result: {result}")
            else:
                print("❌ session has no call_tool method!")
    except Exception as e:
        print(f"Error: {e}")
        import traceback
        traceback.print_exc()
 
if __name__ == "__main__":
    asyncio.run(check_sessions())