#!/usr/bin/env python3
"""
Comprehensive test for both RAG and Jira agents
Tests connectivity, functionality, and error handling
"""
import asyncio
import httpx
import sys
import os

# Add src to path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'src'))

async def test_rag_agent():
    """Test RAG agent directly"""
    print("\n" + "=" * 80)
    print("🧪 TESTING RAG AGENT")
    print("=" * 80)
    
    try:
        from rag_agent import handle_query
        
        # Test query
        query = "tell me information about TMA solution"
        print(f"\n📝 Query: {query}")
        
        result = await handle_query(query)
        
        print(f"\n✅ RAG Agent Response:")
        print(f"   Answer length: {len(result.get('answer', ''))} chars")
        print(f"   Sources: {len(result.get('sources', []))} sources")
        print(f"\n   Answer preview: {result.get('answer', '')[:200]}...")
        
        return True
    except Exception as e:
        print(f"\n❌ RAG Agent Error: {e}")
        import traceback
        traceback.print_exc()
        return False

async def test_jira_agent():
    """Test Jira agent directly"""
    print("\n" + "=" * 80)
    print("🧪 TESTING JIRA AGENT")
    print("=" * 80)
    
    try:
        from jira_agent import jira_agent
        
        # Test query
        query = "List all projects in Jira"
        print(f"\n📝 Query: {query}")
        
        result = await jira_agent.run(query)
        response = result.data if hasattr(result, 'data') else str(result)
        
        print(f"\n✅ Jira Agent Response:")
        print(f"   Response length: {len(response)} chars")
        print(f"\n   Response preview: {response[:300]}...")
        
        return True
    except Exception as e:
        print(f"\n❌ Jira Agent Error: {e}")
        import traceback
        traceback.print_exc()
        return False

async def test_server_endpoints():
    """Test server REST endpoints"""
    print("\n" + "=" * 80)
    print("🧪 TESTING SERVER ENDPOINTS")
    print("=" * 80)
    
    base_url = "http://localhost:8000"
    
    # Test RAG endpoint
    print("\n📡 Testing RAG endpoint (/rag)...")
    try:
        async with httpx.AsyncClient(timeout=30.0) as client:
            response = await client.post(
                f"{base_url}/rag",
                json={"question": "tell me about TMA solution"}
            )
            print(f"   Status: {response.status_code}")
            if response.status_code == 200:
                data = response.json()
                print(f"   ✅ RAG endpoint working: {len(data.get('answer', ''))} chars")
            else:
                print(f"   ❌ RAG endpoint error: {response.text[:200]}")
    except Exception as e:
        print(f"   ❌ Failed to connect to RAG endpoint: {e}")
    
    # Test Jira endpoint
    print("\n📡 Testing Jira endpoint (/jira/query)...")
    try:
        async with httpx.AsyncClient(timeout=30.0) as client:
            response = await client.post(
                f"{base_url}/jira/query",
                json={"query": "List all projects"}
            )
            print(f"   Status: {response.status_code}")
            if response.status_code == 200:
                data = response.json()
                print(f"   ✅ Jira endpoint working: {data.get('success', False)}")
                print(f"   Response: {data.get('response', '')[:200]}...")
            else:
                print(f"   ❌ Jira endpoint error: {response.text[:200]}")
    except Exception as e:
        print(f"   ❌ Failed to connect to Jira endpoint: {e}")

async def main():
    """Run all tests"""
    print("\n" + "=" * 80)
    print("🚀 COMPREHENSIVE AGENT TESTING")
    print("=" * 80)
    
    # Test agents directly
    rag_ok = await test_rag_agent()
    jira_ok = await test_jira_agent()
    
    # Test server endpoints if running
    await test_server_endpoints()
    
    # Summary
    print("\n" + "=" * 80)
    print("📊 TEST SUMMARY")
    print("=" * 80)
    print(f"   RAG Agent:  {'✅ PASS' if rag_ok else '❌ FAIL'}")
    print(f"   Jira Agent: {'✅ PASS' if jira_ok else '❌ FAIL'}")
    print("=" * 80 + "\n")

if __name__ == "__main__":
    asyncio.run(main())
