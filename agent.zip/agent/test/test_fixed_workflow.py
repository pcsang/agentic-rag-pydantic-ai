#!/usr/bin/env python3
"""
Test the fixed workflow for both conversational and technical queries
"""
import asyncio
import sys
from pathlib import Path

# Add src to path
src_path = Path(__file__).parent / "src"
sys.path.insert(0, str(src_path))

# Load environment
from dotenv import load_dotenv
env_path = Path(__file__).parent / ".env"
load_dotenv(env_path)

from rag_agent import query_rag_system

async def test_fixed_workflow():
    """Test both conversational and technical queries with fixed workflow"""
    
    test_cases = [
        ("Hello", "Should be LLM_FALLBACK with minimal workflow"),
        ("steps to set deployment profile in SO Docker", "Should be WEB_ONLY with full workflow")
    ]
    
    for query, expected_behavior in test_cases:
        print(f"🧪 Testing Fixed Workflow")
        print(f"Query: '{query}'")
        print(f"Expected: {expected_behavior}")
        print("=" * 60)
        
        try:
            result = await query_rag_system(query)
            
            print(f"✅ Strategy: {result.strategy_used}")
            print(f"✅ Workflow: {' → '.join(result.agent_workflow)}")
            print(f"✅ Sources: {len(result.sources)}")
            print(f"✅ Web Search: {result.used_web_search}")
            
            # Analyze efficiency
            workflow_length = len(result.agent_workflow)
            if query == "Hello":
                if result.strategy_used == "llm_fallback" and workflow_length <= 2:
                    print(f"🎉 EFFICIENT: Conversational query handled with minimal workflow!")
                else:
                    print(f"⚠️  Issue: Conversational query should have minimal workflow")
            else:
                if result.strategy_used in ["web_only", "local_only"] and len(result.sources) > 0:
                    print(f"🎉 CORRECT: Technical query handled with proper retrieval!")
                else:
                    print(f"⚠️  Issue: Technical query should find sources")
            
            print(f"\n📝 Answer Preview:")
            preview = result.answer[:150] + "..." if len(result.answer) > 150 else result.answer
            print(preview)
            
        except Exception as e:
            print(f"❌ Error: {e}")
            import traceback
            traceback.print_exc()
        
        print(f"\n" + "="*60 + "\n")

if __name__ == "__main__":
    asyncio.run(test_fixed_workflow())