#!/bin/bash
# Restart MCP Server with correct Jira credentials

echo "🔄 Restarting MCP Atlassian Server with updated credentials..."

# Stop existing container
echo "Stopping existing mcp-server container..."
docker stop mcp-server 2>/dev/null
docker rm mcp-server 2>/dev/null

# Get credentials from .env file
source .env

# Start new container with correct credentials
echo "Starting new mcp-server container..."
docker run -d \
  --name mcp-server \
  --restart unless-stopped \
  --network customer-support-docker_demo \
  -p 9000:9000 \
  -e JIRA_URL="${JIRA_URL}" \
  -e JIRA_USERNAME="${JIRA_USERNAME}" \
  -e JIRA_API_TOKEN="${JIRA_API_TOKEN}" \
  -e MCP_VERBOSE="true" \
  -e JIRA_SSL_VERIFY="false" \
  ghcr.io/sooperset/mcp-atlassian:latest \
  --transport streamable-http --port 9000 -vv

echo ""
echo "✅ MCP Server restarted!"
echo "📡 Server running at: http://localhost:9000/mcp"
echo ""
echo "Waiting 3 seconds for server to start..."
sleep 3

# Test connection
echo "Testing MCP server connection..."
curl -s -H "Accept: application/json, text/event-stream" \
     -H "Content-Type: application/json" \
     -X POST http://localhost:9000/mcp/ \
     -d '{"jsonrpc":"2.0","id":"1","method":"initialize","params":{"protocolVersion":"2024-11-05","capabilities":{},"clientInfo":{"name":"test","version":"1.0"}}}' \
     | grep -q "Atlassian MCP" && echo "✅ MCP Server responding correctly!" || echo "⚠️  MCP Server may not be ready yet"

echo ""
echo "🎫 Jira Configuration:"
echo "   URL: ${JIRA_URL}"
echo "   Username: ${JIRA_USERNAME}"
echo "   Token: ${JIRA_API_TOKEN:0:20}...${JIRA_API_TOKEN: -10}"
