#!/bin/bash
# Test Runner Script for Multi-Agent System
# Runs all test suites with proper setup and reporting

set -e  # Exit on error

echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "  🧪 MULTI-AGENT SYSTEM - TEST RUNNER"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""

# Change to agent directory
cd "$(dirname "$0")"

# Activate virtual environment
if [ -f ".venv/bin/activate" ]; then
    echo "✅ Activating virtual environment..."
    source .venv/bin/activate
else
    echo "❌ Virtual environment not found at .venv/"
    echo "   Please create it with: python -m venv .venv && source .venv/bin/activate && pip install -r requirements.txt"
    exit 1
fi

# Check if .env exists
if [ ! -f ".env" ]; then
    echo "⚠️  Warning: .env file not found. Environment variables may not be set."
    echo "   Copy from .env.example if needed."
fi

# Function to check if server is running
check_server() {
    curl -s -o /dev/null -w "%{http_code}" http://localhost:8000/ 2>/dev/null
}

# Parse command line arguments
TEST_TYPE="${1:-all}"
SERVER_RUNNING=false

echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "  TEST CONFIGURATION"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "  Test Type: $TEST_TYPE"
echo "  Options: unit, integration, supervisor, all"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""

# Run unit tests
if [ "$TEST_TYPE" = "unit" ] || [ "$TEST_TYPE" = "all" ]; then
    echo ""
    echo "🧪 Running Unit Tests..."
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    python test_unit.py
    UNIT_EXIT=$?
    
    if [ $UNIT_EXIT -eq 0 ]; then
        echo "✅ Unit tests passed"
    else
        echo "❌ Unit tests failed"
        if [ "$TEST_TYPE" = "unit" ]; then
            exit $UNIT_EXIT
        fi
    fi
fi

# Run supervisor tests
if [ "$TEST_TYPE" = "supervisor" ] || [ "$TEST_TYPE" = "all" ]; then
    echo ""
    echo "🎯 Running Supervisor Tests..."
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    python test_supervisor.py
    SUPERVISOR_EXIT=$?
    
    if [ $SUPERVISOR_EXIT -eq 0 ]; then
        echo "✅ Supervisor tests passed"
    else
        echo "❌ Supervisor tests failed"
        if [ "$TEST_TYPE" = "supervisor" ]; then
            exit $SUPERVISOR_EXIT
        fi
    fi
fi

# Run integration tests (require server)
if [ "$TEST_TYPE" = "integration" ] || [ "$TEST_TYPE" = "all" ]; then
    echo ""
    echo "🌐 Checking if server is running..."
    HTTP_CODE=$(check_server)
    
    if [ "$HTTP_CODE" = "200" ] || [ "$HTTP_CODE" = "404" ]; then
        echo "✅ Server is running at http://localhost:8000"
        SERVER_RUNNING=true
    else
        echo "⚠️  Server not running. Integration tests require the server."
        echo "   Start the server with: python src/main.py"
        echo "   Or run integration tests separately after starting the server."
        
        if [ "$TEST_TYPE" = "integration" ]; then
            exit 1
        else
            echo "   Skipping integration tests..."
        fi
    fi
    
    if [ "$SERVER_RUNNING" = true ]; then
        echo ""
        echo "🚀 Running Integration Tests..."
        echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
        python test_workflow.py
        INTEGRATION_EXIT=$?
        
        if [ $INTEGRATION_EXIT -eq 0 ]; then
            echo "✅ Integration tests passed"
        else
            echo "❌ Integration tests failed"
            if [ "$TEST_TYPE" = "integration" ]; then
                exit $INTEGRATION_EXIT
            fi
        fi
    fi
fi

# Summary
echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "  📊 TEST SUMMARY"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

if [ "$TEST_TYPE" = "unit" ] || [ "$TEST_TYPE" = "all" ]; then
    if [ $UNIT_EXIT -eq 0 ]; then
        echo "  ✅ Unit Tests: PASSED"
    else
        echo "  ❌ Unit Tests: FAILED"
    fi
fi

if [ "$TEST_TYPE" = "supervisor" ] || [ "$TEST_TYPE" = "all" ]; then
    if [ $SUPERVISOR_EXIT -eq 0 ]; then
        echo "  ✅ Supervisor Tests: PASSED"
    else
        echo "  ❌ Supervisor Tests: FAILED"
    fi
fi

if [ "$TEST_TYPE" = "integration" ] || [ "$TEST_TYPE" = "all" ]; then
    if [ "$SERVER_RUNNING" = true ]; then
        if [ $INTEGRATION_EXIT -eq 0 ]; then
            echo "  ✅ Integration Tests: PASSED"
        else
            echo "  ❌ Integration Tests: FAILED"
        fi
    else
        echo "  ⚠️  Integration Tests: SKIPPED (server not running)"
    fi
fi

echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""

# Check if any tests failed
ALL_PASSED=true

if [ "$TEST_TYPE" = "unit" ] || [ "$TEST_TYPE" = "all" ]; then
    [ $UNIT_EXIT -ne 0 ] && ALL_PASSED=false
fi

if [ "$TEST_TYPE" = "supervisor" ] || [ "$TEST_TYPE" = "all" ]; then
    [ $SUPERVISOR_EXIT -ne 0 ] && ALL_PASSED=false
fi

if [ "$TEST_TYPE" = "integration" ] || [ "$TEST_TYPE" = "all" ]; then
    if [ "$SERVER_RUNNING" = true ]; then
        [ $INTEGRATION_EXIT -ne 0 ] && ALL_PASSED=false
    fi
fi

if [ "$ALL_PASSED" = true ]; then
    echo "🎉 All tests completed successfully!"
    echo ""
    exit 0
else
    echo "⚠️  Some tests failed. Check the output above for details."
    echo ""
    exit 1
fi
