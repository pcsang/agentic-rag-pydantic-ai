"use client";

import { CopilotKitCSSProperties, CopilotChat } from "@copilotkit/react-ui";
import { CopilotKit } from "@copilotkit/react-core";

export default function CopilotKitPage() {
  return (
    <CopilotKit runtimeUrl="/api/copilotkit">
      <MainContent />
    </CopilotKit>
  );
}

function MainContent() {
  return (
    <main style={{ "--copilot-kit-primary-color": "#3b82f6" } as CopilotKitCSSProperties}>
      <div className="h-screen w-screen flex flex-col bg-gradient-to-br from-slate-50 to-blue-50 dark:from-slate-900 dark:to-slate-800">
        {/* Professional Header */}
        <header className="bg-gradient-to-r from-slate-900 via-slate-800 to-black shadow-2xl border-b border-slate-700">
          <div className="max-w-full px-8 py-7 flex items-center justify-center">
            <div className="flex items-center gap-5">
              {/* Professional Brain/AI Icon */}
              <div className="w-16 h-16 bg-gradient-to-br from-blue-500 via-blue-600 to-indigo-700 rounded-2xl flex items-center justify-center shadow-2xl hover:shadow-3xl transition-shadow duration-300">
                <svg className="w-9 h-9 text-white" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"/>
                </svg>
              </div>
              <div className="flex flex-col">
                <h1 className="text-5xl font-bold text-white tracking-tighter">RAG Agentic</h1>
                <p className="text-slate-400 text-sm font-semibold mt-1">Retrieval-Augmented Generation System</p>
              </div>
            </div>
          </div>
        </header>

        {/* Fullscreen Chat */}
        <div className="flex-1 overflow-hidden">
          <CopilotChat
            instructions="You are a RAG system proxy. Your ONLY job is to:

1. Call query_rag tool for EVERY user question
2. Return the COMPLETE tool response WORD-FOR-WORD, including:
   - All answer text
   - ALL metadata sections (workflow, scores, sources)
   - ALL source references and links
3. DO NOT summarize, paraphrase, or modify ANY part
4. DO NOT add your own commentary
5. DO NOT omit sources or metadata
6. Show EVERYTHING from the tool response

You are a pass-through. Return tool output verbatim."
            labels={{
              title: "Ask a question...",
              initial: "Ask about documentation and technical questions..."
            }}
            className="h-full w-full"
          />
        </div>
      </div>
    </main>
  );
}
